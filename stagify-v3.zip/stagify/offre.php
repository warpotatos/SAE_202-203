<?php
// offre.php — Détail d'une offre de stage (+ bouton Postuler).
require_once "includes/fonctions.php";
require_once "config/connexion.php";

// On récupère le numéro de l'offre dans l'URL (offre.php?id=...).
$id = 0;
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
}

// On lit l'offre avec les infos de l'entreprise.
$requete = $pdo->prepare("SELECT o.*, e.nom AS entreprise, e.ville
                          FROM offre_stage o
                          JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                          WHERE o.num_offre = ?");
$requete->execute([$id]);
$offre = $requete->fetch();

// Si l'offre n'existe pas, on retourne au catalogue.
if (!$offre) {
    header("Location: catalogue.php");
    exit;
}

// Quelques offres similaires (les autres offres ouvertes).
$similaires = $pdo->prepare("SELECT o.num_offre, o.titre, o.duree, e.nom AS entreprise
                             FROM offre_stage o
                             JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                             WHERE o.statut = 'ouverte' AND o.num_offre != ?
                             ORDER BY o.date_publication DESC LIMIT 3");
$similaires->execute([$id]);
$autres = $similaires->fetchAll();

$racine = "";
$actif = "catalogue.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — <?php echo e($offre['titre']); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div class="contenu">
    <a href="catalogue.php" style="font-weight:700;color:#1565d8;">← Retour aux offres</a>

    <div class="bloc" style="margin-top:14px;">
        <h2 style="font-size:28px;"><?php echo e($offre['titre']); ?></h2>
        <p style="color:#6b7785;font-weight:700;">Description</p>
        <div class="champ-bloc"><?php echo e($offre['description']); ?></div>

        <div class="grille-2" style="margin-top:24px;">
            <div>
                <p style="font-weight:800;font-size:18px;">Nom entreprise</p>
                <div class="champ-bloc petit"><?php echo e($offre['entreprise']); ?></div>
                <?php if ($offre['ville']) { ?><p style="color:#6b7785;">📍 <?php echo e($offre['ville']); ?></p><?php } ?>
            </div>
            <div>
                <p style="font-weight:800;font-size:18px;">Durée possible</p>
                <div class="champ-bloc petit"><?php echo e($offre['duree']); ?></div>
                <p style="color:#6b7785;">Publiée le <?php echo e($offre['date_publication']); ?></p>
            </div>
        </div>

        <div style="text-align:right;margin-top:20px;">
            <?php if (estConnecte() && roleConnecte() == "etudiant") { ?>
                <a class="bouton-postuler" href="etudiant/postuler.php?offre=<?php echo $offre['num_offre']; ?>">Postuler</a>
            <?php } else { ?>
                <a class="bouton-postuler" href="connexion_etudiant.php">Se connecter pour postuler</a>
            <?php } ?>
        </div>
    </div>

    <h2 class="titre-section">Offres similaires</h2>
    <div class="grille-offres">
        <?php foreach ($autres as $autre) { ?>
            <div class="carte-offre">
                <h3><?php echo e($autre['titre']); ?></h3>
                <div class="entreprise"><?php echo e($autre['entreprise']); ?></div>
                <div class="bas">
                    <div><small>Description du poste</small><small>Durée : <?php echo e($autre['duree']); ?></small></div>
                    <a class="plus" href="offre.php?id=<?php echo $autre['num_offre']; ?>">+</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
