<?php
// includes/footer.php
// Pied de page commun.
?>
<footer class="pied">
    <div class="pied-colonnes">
        <div>
            <h4>Qui sommes-nous ?</h4>
            <a href="#">À propos de Stagify</a>
            <a href="#">Nos partenaires</a>
        </div>
        <div>
            <h4>Support</h4>
            <a href="#">Aide</a>
            <a href="#">FAQ</a>
        </div>
        <div>
            <h4>Restons en contact</h4>
            <a href="#">support@stagify.fr</a>
            <a href="#">01 23 45 67 89</a>
        </div>
        <div>
            <h4>Suivez-nous</h4>
            <div class="reseaux">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="#1d2b36"><path d="M13 10h3l.5-3H13V5.5c0-.9.3-1.5 1.6-1.5H17V1.4C16.6 1.3 15.4 1.2 14 1.2 11.2 1.2 9.3 2.9 9.3 6v1H6.5v3H9.3v9h3.7z"/></svg>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="#1d2b36"><path d="M22 5.8c-.7.3-1.5.6-2.3.7.8-.5 1.4-1.3 1.7-2.2-.8.5-1.7.8-2.6 1A4 4 0 0 0 12 8.8c0 .3 0 .6.1.9C8.3 9.5 5 7.7 2.8 5c-.4.7-.6 1.4-.6 2.2 0 1.4.7 2.6 1.8 3.3-.6 0-1.3-.2-1.8-.5v.1c0 2 1.4 3.6 3.2 4-.3.1-.7.1-1 .1-.3 0-.5 0-.8-.1.5 1.6 2 2.8 3.8 2.8A8 8 0 0 1 2 18.6 11.3 11.3 0 0 0 8.1 20c7.3 0 11.3-6 11.3-11.3v-.5c.8-.6 1.5-1.3 2-2.1z"/></svg>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="#1d2b36"><path d="M6.9 8.2H3.6V21h3.3zM5.3 3.4a1.9 1.9 0 1 0 0 3.8 1.9 1.9 0 0 0 0-3.8M21 21v-7c0-3.4-.7-6-4.7-6-1.9 0-3.2 1.1-3.7 2.1h-.1V8.2H9.4V21h3.3v-6.3c0-1.7.3-3.3 2.4-3.3 2 0 2.1 1.9 2.1 3.4V21z"/></svg>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1d2b36" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="#1d2b36" stroke="none"/></svg>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="#1d2b36"><path d="M23 7.5a3 3 0 0 0-2.1-2.1C19 4.9 12 4.9 12 4.9s-7 0-8.9.5A3 3 0 0 0 1 7.5C.5 9.4.5 12 .5 12s0 2.6.5 4.5a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-4.5.5-4.5s0-2.6-.5-4.5M9.7 15.3V8.7l5.8 3.3z"/></svg>
            </div>
        </div>
    </div>
    <div class="pied-copyright">© 2026 Stagify — Tous droits réservés.</div>
</footer>
