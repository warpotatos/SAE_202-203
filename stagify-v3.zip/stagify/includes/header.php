<?php
// includes/header.php
// En-tête commun. Avant de l'inclure, on peut définir :
//   $racine = chemin vers la racine du site ("" à la racine, "../" dans un dossier)
//   $actif  = nom du fichier de la page courante (pour surligner le menu)

if (!isset($racine)) { $racine = ""; }
if (!isset($actif))  { $actif  = ""; }

$role = roleConnecte();

// Dossier du rôle (pour le lien vers le profil).
$dossier = "";
if ($role == "etudiant")         { $dossier = "etudiant"; }
elseif ($role == "enseignant")   { $dossier = "enseignant"; }
elseif ($role == "maitre_stage") { $dossier = "professionnel"; }
elseif ($role == "admin")        { $dossier = "admin"; }

// Le menu : chaque lien est écrit depuis la racine, avec $racine devant.
if ($role == "etudiant") {
    $menu = array(
        $racine . "etudiant/dashboard.php"    => "Accueil",
        $racine . "catalogue.php"             => "Stages",
        $racine . "etudiant/candidatures.php" => "Mes demandes"
    );
} elseif ($role == "enseignant") {
    $menu = array(
        $racine . "enseignant/dashboard.php" => "Accueil",
        $racine . "enseignant/etudiants.php" => "Mes étudiants",
        $racine . "enseignant/visites.php"   => "Mes Visites"
    );
} elseif ($role == "maitre_stage") {
    $menu = array(
        $racine . "professionnel/dashboard.php"    => "Accueil",
        $racine . "professionnel/stagiaires.php"   => "Mes stagiaires",
        $racine . "professionnel/candidatures.php" => "Demandes reçues"
    );
} elseif ($role == "admin") {
    $menu = array(
        $racine . "admin/dashboard.php"    => "Accueil",
        $racine . "admin/utilisateurs.php" => "Utilisateurs",
        $racine . "admin/offres.php"       => "Offres"
    );
} else {
    $menu = array(
        $racine . "catalogue.php" => "Stages"
    );
}
?>
<header class="entete">
    <a class="logo-carre" href="<?php echo $racine; ?>index.php">
        <img src="<?php echo $racine; ?>img/logo.svg" alt="Stagify" width="42" height="42">
    </a>

    <nav class="menu">
        <?php foreach ($menu as $lien => $libelle) { ?>
            <a href="<?php echo $lien; ?>" class="<?php if ($actif == basename($lien)) echo 'actif'; ?>"><?php echo $libelle; ?></a>
        <?php } ?>
    </nav>

    <div class="entete-droite">
        <?php if (estConnecte()) { ?>
            <a class="bouton-icone" href="<?php echo $racine; ?>messagerie.php" title="Notifications">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
            </a>
            <a class="bouton-icone" href="<?php echo $racine; ?>messagerie.php" title="Messagerie">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
            </a>
            <a class="avatar" href="<?php echo $racine . $dossier; ?>/profil.php" title="Profil">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.5" r="3.8"/><path d="M5 20c0-3.6 3.3-5.5 7-5.5s7 1.9 7 5.5"/></svg>
            </a>
        <?php } else { ?>
            <a class="menu" href="<?php echo $racine; ?>index.php" style="font-weight:600;">Connexion</a>
            <span class="avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.5" r="3.8"/><path d="M5 20c0-3.6 3.3-5.5 7-5.5s7 1.9 7 5.5"/></svg>
            </span>
        <?php } ?>
    </div>
</header>
