<?php
// includes/fonctions.php
// Quelques petites fonctions utiles, réutilisées dans tout le site.

session_start();

// Raccourci pour protéger l'affichage du texte (évite les failles).
function e($texte) {
    return htmlspecialchars($texte);
}

// Vrai si un utilisateur est connecté.
function estConnecte() {
    return isset($_SESSION['user_id']);
}

// Renvoie le rôle de l'utilisateur connecté ("etudiant", "enseignant"...).
function roleConnecte() {
    if (isset($_SESSION['role'])) {
        return $_SESSION['role'];
    }
    return "";
}

// Renvoie une pastille de couleur selon le statut d'une candidature/stage.
function pastilleStatut($statut) {
    if ($statut == "en_attente") {
        return '<span class="pastille pastille-attente">En attente ...</span>';
    } elseif ($statut == "acceptee") {
        return '<span class="pastille pastille-encours">Acceptée</span>';
    } elseif ($statut == "refusee") {
        return '<span class="pastille pastille-refus">Refus</span>';
    }
    return '<span class="pastille pastille-aucun">—</span>';
}

// Protège une page : si pas connecté avec le bon rôle, on redirige.
function proteger($role) {
    if (!estConnecte() || $_SESSION['role'] != $role) {
        header("Location: ../index.php");
        exit;
    }
}
?>
