<?php
// enseignant/notes.php — Saisir une note de stage + historique.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("enseignant");

$req = $pdo->prepare("SELECT num_enseignant FROM enseignant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$ens = $req->fetch();
$numEnseignant = $ens['num_enseignant'];

// Les stages des étudiants suivis (pour le menu déroulant).
$reqStages = $pdo->prepare("SELECT s.num_stage, e.nom, e.prenom
                            FROM stage s
                            JOIN etudiant e ON e.id_etudiant = s.id_etudiant
                            WHERE e.num_enseignant_ref = ?");
$reqStages->execute([$numEnseignant]);
$stages = $reqStages->fetchAll();

// Les notes déjà saisies par cet enseignant.
$reqNotes = $pdo->prepare("SELECT e.nom, e.prenom, ent.nom AS entreprise,
                                  n.note, n.date_notation, n.commentaire
                           FROM notation n
                           JOIN stage s        ON s.num_stage = n.num_stage
                           JOIN etudiant e     ON e.id_etudiant = s.id_etudiant
                           JOIN entreprise ent ON ent.id_entreprise = s.id_entreprise
                           WHERE n.num_enseignant = ?
                           ORDER BY n.date_notation DESC");
$reqNotes->execute([$numEnseignant]);
$notes = $reqNotes->fetchAll();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Note &amp; Évaluation</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <form class="bloc" action="../traitements/noter.php" method="post">
        <h2>Saisir une note de stage</h2>
        <div class="grille-2">
            <div>
                <label style="font-weight:700;">Étudiant</label>
                <select name="num_stage" required style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;">
                    <option value="">Choisir</option>
                    <?php foreach ($stages as $st) { ?>
                        <option value="<?php echo $st['num_stage']; ?>"><?php echo e($st['nom'] . " " . $st['prenom']); ?></option>
                    <?php } ?>
                </select>
            </div>
            <div></div>
            <div>
                <label style="font-weight:700;">Note /20</label>
                <input type="number" name="note" min="0" max="20" step="0.5" required style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;">
            </div>
            <div>
                <label style="font-weight:700;">Date</label>
                <input type="date" name="date" required style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;">
            </div>
        </div>
        <label style="font-weight:700;display:block;margin-top:14px;">Commentaire</label>
        <textarea name="commentaire" rows="3" placeholder="Remarque sur le stage ..." style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;"></textarea>
        <div style="text-align:right;margin-top:16px;"><button type="submit" class="bouton-postuler">Enregistrer</button></div>
    </form>

    <table class="tableau">
        <thead><tr><th>ÉTUDIANT</th><th>ENTREPRISE</th><th>NOTE</th><th>DATE</th><th>COMMENTAIRE</th></tr></thead>
        <tbody>
        <?php foreach ($notes as $n) { ?>
            <tr>
                <td><?php echo e($n['nom'] . " " . $n['prenom']); ?></td>
                <td><?php echo e($n['entreprise']); ?></td>
                <td><?php echo e($n['note']); ?>/20</td>
                <td><?php echo e($n['date_notation']); ?></td>
                <td><?php echo e($n['commentaire']); ?></td>
            </tr>
        <?php } ?>
        <?php if (count($notes) == 0) { ?>
            <tr><td colspan="5" style="color:#6b7785;">Aucune note saisie pour le moment.</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
