<?php
// enseignant/dashboard.php — Accueil enseignant (tuiles).
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("enseignant");

$racine = "../";
$versRacine = "../";
$actif = "dashboard.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Accueil enseignant</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu"><?php include "../includes/barre_recherche.php"; ?></div>

<div class="contenu">
    <a class="tuile large" href="etudiants.php">Suivi élève<span class="plus">+</span></a>
    <div class="grille-tuiles">
        <a class="tuile" href="visites.php">Jury / Soutenance<span class="plus">+</span></a>
        <a class="tuile" href="problemes.php">Problème élève<span class="plus">+</span></a>
        <a class="tuile" href="notes.php">NOTE &amp; Évaluation<span class="plus">+</span></a>
        <a class="tuile" href="../catalogue.php">Offre de Stage<span class="plus">+</span></a>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
