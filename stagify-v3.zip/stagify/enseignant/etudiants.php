<?php
// enseignant/etudiants.php — Liste des étudiants suivis.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("enseignant");

$req = $pdo->prepare("SELECT num_enseignant FROM enseignant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$ens = $req->fetch();

$liste = $pdo->prepare("SELECT e.nom, e.prenom, e.TD, e.TP, e.email,
                               ent.nom AS entreprise, s.duree AS periode,
                               s.num_stage
                        FROM etudiant e
                        LEFT JOIN stage s       ON s.id_etudiant = e.id_etudiant
                        LEFT JOIN entreprise ent ON ent.id_entreprise = s.id_entreprise
                        WHERE e.num_enseignant_ref = ?
                        ORDER BY e.nom");
$liste->execute([$ens['num_enseignant']]);
$etudiants = $liste->fetchAll();

$racine = "../";
$actif = "etudiants.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Mes étudiants</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Mes étudiants</h2>
    <table class="tableau">
        <thead><tr><th>NOM</th><th>PRÉNOM</th><th>TD/TP</th><th>EMAIL</th><th>ENTREPRISE</th><th>PÉRIODE</th><th>STATUT</th></tr></thead>
        <tbody>
        <?php foreach ($etudiants as $e) { ?>
            <tr>
                <td><?php echo e($e['nom']); ?></td>
                <td><?php echo e($e['prenom']); ?></td>
                <td><?php echo e($e['TD'] . "/" . $e['TP']); ?></td>
                <td><?php echo e($e['email']); ?></td>
                <td><?php echo $e['entreprise'] ? e($e['entreprise']) : "—"; ?></td>
                <td><?php echo $e['periode'] ? e($e['periode']) : "—"; ?></td>
                <td>
                    <?php if ($e['num_stage']) { ?>
                        <span class="pastille pastille-encours">Stage en cours</span>
                    <?php } else { ?>
                        <span class="pastille pastille-aucun">Pas de Stage</span>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
