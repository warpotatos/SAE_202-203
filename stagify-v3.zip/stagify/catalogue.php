<?php
// catalogue.php — Liste des offres de stage (publique, et "Stages" pour l'étudiant).
require_once "includes/fonctions.php";
require_once "config/connexion.php";

// On lit les offres ouvertes avec le nom de l'entreprise.
$requete = $pdo->query("SELECT o.num_offre, o.titre, o.duree, e.nom AS entreprise
                        FROM offre_stage o
                        JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                        WHERE o.statut = 'ouverte'
                        ORDER BY o.date_publication DESC");
$offres = $requete->fetchAll();

$racine = "";       // on est à la racine
$versRacine = "";   // pour la barre de recherche
$actif = "catalogue.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Offres de stage</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>
<div class="contenu"><?php include "includes/barre_recherche.php"; ?></div>

<div class="contenu">
    <div class="grille-offres">
        <?php foreach ($offres as $offre) { ?>
            <div class="carte-offre">
                <h3><?php echo e($offre['titre']); ?></h3>
                <div class="entreprise"><?php echo e($offre['entreprise']); ?></div>
                <div class="bas">
                    <div>
                        <small>Description du poste</small>
                        <small>Durée : <?php echo e($offre['duree']); ?></small>
                    </div>
                    <a class="plus" href="offre.php?id=<?php echo $offre['num_offre']; ?>" title="Voir l'offre">+</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
