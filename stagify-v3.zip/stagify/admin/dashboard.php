<?php
// admin/dashboard.php — Accueil administrateur (tuiles).
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("admin");

$racine = "../";
$actif = "dashboard.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Administration</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Administration</h2>
    <a class="tuile large" href="utilisateurs.php">Gestion des utilisateurs<span class="plus">+</span></a>
    <div class="grille-tuiles">
        <a class="tuile" href="offres.php">Gestion des offres<span class="plus">+</span></a>
        <a class="tuile" href="statistiques.php">Statistiques<span class="plus">+</span></a>
        <a class="tuile" href="../messagerie.php">Messagerie<span class="plus">+</span></a>
        <a class="tuile" href="profil.php">Mon profil<span class="plus">+</span></a>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
