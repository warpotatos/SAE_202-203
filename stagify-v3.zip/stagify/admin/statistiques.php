<?php
// admin/statistiques.php — Quelques chiffres sur la plateforme.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("admin");

// Une petite fonction pour compter les lignes d'une table.
function compter($pdo, $table) {
    $r = $pdo->query("SELECT COUNT(*) AS n FROM " . $table);
    $ligne = $r->fetch();
    return $ligne['n'];
}

$stats = array(
    "Étudiants"     => compter($pdo, "etudiant"),
    "Enseignants"   => compter($pdo, "enseignant"),
    "Professionnels"=> compter($pdo, "maitre_stage"),
    "Entreprises"   => compter($pdo, "entreprise"),
    "Offres"        => compter($pdo, "offre_stage"),
    "Candidatures"  => compter($pdo, "postulation"),
    "Stages"        => compter($pdo, "stage"),
    "Messages"      => compter($pdo, "message")
);

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Statistiques</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Statistiques</h2>
    <div class="grille-stats">
        <?php foreach ($stats as $libelle => $valeur) { ?>
            <div class="carte-stat">
                <div class="chiffre"><?php echo $valeur; ?></div>
                <div class="libelle"><?php echo e($libelle); ?></div>
            </div>
        <?php } ?>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
