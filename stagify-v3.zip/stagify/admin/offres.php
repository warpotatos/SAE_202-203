<?php
// admin/offres.php — Liste de toutes les offres + fermeture / suppression.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("admin");

$offres = $pdo->query("SELECT o.num_offre, o.titre, o.statut, o.date_publication, e.nom AS entreprise
                       FROM offre_stage o
                       JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                       ORDER BY o.date_publication DESC")->fetchAll();

$racine = "../";
$actif = "offres.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Offres</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Gestion des offres (<?php echo count($offres); ?>)</h2>
    <table class="tableau">
        <thead><tr><th>OFFRE</th><th>ENTREPRISE</th><th>PUBLIÉE LE</th><th>STATUT</th><th>ACTION</th></tr></thead>
        <tbody>
        <?php foreach ($offres as $o) { ?>
            <tr>
                <td><?php echo e($o['titre']); ?></td>
                <td><?php echo e($o['entreprise']); ?></td>
                <td><?php echo e($o['date_publication']); ?></td>
                <td>
                    <?php if ($o['statut'] == 'ouverte') { ?><span class="pastille pastille-encours">Ouverte</span>
                    <?php } elseif ($o['statut'] == 'pourvue') { ?><span class="pastille pastille-avenir">Pourvue</span>
                    <?php } else { ?><span class="pastille pastille-aucun">Fermée</span><?php } ?>
                </td>
                <td>
                    <?php if ($o['statut'] == 'ouverte') { ?>
                        <a href="../traitements/fermer_offre.php?num=<?php echo $o['num_offre']; ?>" style="color:#0c7c8c;font-weight:700;">Fermer</a>
                        &nbsp;|&nbsp;
                    <?php } ?>
                    <a href="../traitements/supprimer_offre.php?num=<?php echo $o['num_offre']; ?>"
                       onclick="return confirm('Supprimer cette offre ?');"
                       style="color:#b42318;font-weight:700;">Supprimer</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
