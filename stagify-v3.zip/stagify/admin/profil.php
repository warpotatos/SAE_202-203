<?php
// admin/profil.php — Profil administrateur.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("admin");

$req = $pdo->prepare("SELECT a.nom, a.prenom, u.email
                      FROM admin a
                      JOIN utilisateur u ON u.num_utilisateur = a.num_utilisateur
                      WHERE a.num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$admin = $req->fetch();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Mon profil</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <div class="profil-bloc">
        <div class="profil-bande">
            <div>
                <div class="profil-label">Rôle</div>
                <div class="champ-bloc">Administrateur</div>
            </div>
            <div class="profil-nom"><span><?php echo e($admin['nom']); ?></span><span><?php echo e($admin['prenom']); ?></span></div>
            <div class="profil-avatar"><svg viewBox="0 0 24 24" width="60" height="60" fill="none" stroke="#7fb6d6" stroke-width="1.6"><circle cx="12" cy="8.5" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg></div>
        </div>
        <div class="profil-label" style="margin-top:18px;">Email</div>
        <div class="champ-bloc"><?php echo e($admin['email']); ?></div>
        <div style="text-align:right;margin-top:24px;">
            <a class="bouton-principal" style="background:#19b6d4;display:inline-flex;width:auto;padding:12px 26px;" href="../traitements/deconnexion.php">Se déconnecter</a>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
