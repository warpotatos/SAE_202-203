<?php
// etudiant/candidatures.php — "Mes demandes" : tableau de toutes les candidatures.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("etudiant");

$req = $pdo->prepare("SELECT id_etudiant FROM etudiant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$etudiant = $req->fetch();

$reqDemandes = $pdo->prepare("SELECT p.date_postulation, p.duree_souhaitee, p.statut, o.titre, e.nom AS entreprise
                              FROM postulation p
                              JOIN offre_stage o ON o.num_offre = p.num_offre
                              JOIN entreprise e  ON e.id_entreprise = o.id_entreprise
                              WHERE p.id_etudiant = ?
                              ORDER BY p.date_postulation DESC");
$reqDemandes->execute([$etudiant['id_etudiant']]);
$demandes = $reqDemandes->fetchAll();

$racine = "../";
$actif = "candidatures.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Mes demandes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include "../includes/header.php"; ?>

<div class="contenu">
    <h2 class="titre-section">Mes demandes</h2>
    <table class="tableau">
        <thead>
            <tr>
                <th>NOM DE L'OFFRE</th><th>DATE DE LA DEMANDE</th>
                <th>ENTREPRISE</th><th>PERIODE</th><th>STATUT</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($demandes) == 0) { ?>
                <tr><td colspan="5" style="color:#6b7785;">Aucune candidature pour le moment.</td></tr>
            <?php } else { ?>
                <?php foreach ($demandes as $d) { ?>
                    <tr>
                        <td><?php echo e($d['titre']); ?></td>
                        <td><?php echo e($d['date_postulation']); ?></td>
                        <td><?php echo e($d['entreprise']); ?></td>
                        <td><?php echo e($d['duree_souhaitee']); ?></td>
                        <td><?php echo pastilleStatut($d['statut']); ?></td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>

</body>
</html>
