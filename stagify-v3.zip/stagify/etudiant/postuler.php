<?php
// etudiant/postuler.php — Formulaire de candidature à une offre.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("etudiant");

// Numéro de l'offre concernée.
$idOffre = 0;
if (isset($_GET['offre'])) {
    $idOffre = (int) $_GET['offre'];
}

// On récupère l'offre pour afficher son titre.
$req = $pdo->prepare("SELECT o.num_offre, o.titre, e.nom AS entreprise
                      FROM offre_stage o
                      JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                      WHERE o.num_offre = ?");
$req->execute([$idOffre]);
$offre = $req->fetch();

if (!$offre) {
    header("Location: ../catalogue.php");
    exit;
}

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Postuler</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include "../includes/header.php"; ?>

<div class="contenu">
    <a href="../offre.php?id=<?php echo $offre['num_offre']; ?>" style="font-weight:700;color:#1565d8;">←</a>
    <h1 style="font-size:34px;margin:6px 0 20px;"><?php echo e($offre['titre']); ?></h1>

    <form class="bloc" action="../traitements/postuler.php" method="post">
        <input type="hidden" name="offre" value="<?php echo $offre['num_offre']; ?>">

        <label style="font-weight:800;font-size:18px;">Motivation</label>
        <textarea name="motivation" rows="6" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;" placeholder="Expliquez votre motivation ..."></textarea>

        <label style="font-weight:800;font-size:18px;display:block;margin-top:20px;">CV</label>
        <input type="file" name="cv" style="margin-top:8px;">

        <label style="font-weight:800;font-size:18px;display:block;margin-top:20px;">Durée souhaitée</label>
        <input type="text" name="duree" placeholder="ex : 3 mois" style="width:260px;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;">

        <div style="text-align:right;margin-top:24px;">
            <button type="submit" class="bouton-postuler">Envoyer</button>
        </div>
    </form>
</div>

<?php include "../includes/footer.php"; ?>

</body>
</html>
