<?php
// traitements/inscription.php — Crée un nouveau compte selon le rôle choisi.
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";

// Champs communs à tous les rôles.
$role       = $_POST['role'];
$nom        = $_POST['nom'];
$prenom     = $_POST['prenom'];
$email      = $_POST['email'];
$login      = $_POST['login'];
$motdepasse = $_POST['motdepasse'];

// Page d'inscription correspondant au rôle (pour revenir en cas d'erreur).
if ($role == "maitre_stage") {
    $pageRetour = "../inscription_professionnel.php";
} elseif ($role == "enseignant") {
    $pageRetour = "../inscription_enseignant.php";
} else {
    $pageRetour = "../inscription_etudiant.php";
}

// 1) Vérification du mot de passe : 8 caractères, une majuscule, un chiffre.
if (strlen($motdepasse) < 8 || !preg_match('/[A-Z]/', $motdepasse) || !preg_match('/[0-9]/', $motdepasse)) {
    header("Location: " . $pageRetour . "?erreur=" . urlencode("Mot de passe trop faible (8 caractères, une majuscule, un chiffre)."));
    exit;
}

// 2) Vérifier que le login ou l'email n'existe pas déjà.
$verif = $pdo->prepare("SELECT num_utilisateur FROM utilisateur WHERE login = ? OR email = ?");
$verif->execute([$login, $email]);
if ($verif->fetch()) {
    header("Location: " . $pageRetour . "?erreur=" . urlencode("Cet identifiant ou cet email est déjà utilisé."));
    exit;
}

// 3) On chiffre le mot de passe avant de l'enregistrer.
$motdepasseChiffre = password_hash($motdepasse, PASSWORD_DEFAULT);

// 4) On insère d'abord dans la table utilisateur.
$ajout = $pdo->prepare("INSERT INTO utilisateur (login, mot_de_passe, email, role) VALUES (?, ?, ?, ?)");
$ajout->execute([$login, $motdepasseChiffre, $email, $role]);

// On récupère le numéro de l'utilisateur qu'on vient de créer.
$numUtilisateur = $pdo->lastInsertId();

// 5) On insère ensuite dans la table du rôle.
if ($role == "etudiant") {
    $telephone = $_POST['telephone'];
    $td = $_POST['td'];
    $tp = $_POST['tp'];
    $req = $pdo->prepare("INSERT INTO etudiant (nom, prenom, email, telephone, TD, TP, num_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $req->execute([$nom, $prenom, $email, $telephone, $td, $tp, $numUtilisateur]);

} elseif ($role == "enseignant") {
    $matiere = $_POST['matiere'];
    $req = $pdo->prepare("INSERT INTO enseignant (nom, prenom, matiere, email, num_utilisateur) VALUES (?, ?, ?, ?, ?)");
    $req->execute([$nom, $prenom, $matiere, $email, $numUtilisateur]);

} elseif ($role == "maitre_stage") {
    // Le professionnel a une entreprise : on crée d'abord l'entreprise.
    $entreprise = $_POST['entreprise'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $telephone = $_POST['telephone'];
    $poste = $_POST['poste'];

    $reqEnt = $pdo->prepare("INSERT INTO entreprise (nom, adresse, ville, telephone) VALUES (?, ?, ?, ?)");
    $reqEnt->execute([$entreprise, $adresse, $ville, $telephone]);
    $idEntreprise = $pdo->lastInsertId();

    $req = $pdo->prepare("INSERT INTO maitre_stage (nom, prenom, email, telephone, poste, id_entreprise, num_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $req->execute([$nom, $prenom, $email, $telephone, $poste, $idEntreprise, $numUtilisateur]);
}

// 6) Inscription réussie : on ouvre la session et on va sur le tableau de bord.
$_SESSION['user_id'] = $numUtilisateur;
$_SESSION['role'] = $role;

if ($role == "etudiant") {
    header("Location: ../etudiant/dashboard.php");
} elseif ($role == "enseignant") {
    header("Location: ../enseignant/dashboard.php");
} else {
    header("Location: ../professionnel/dashboard.php");
}
exit;
?>
