<?php
// traitements/fermer_offre.php — Ferme une offre (admin).
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("admin");

$num = (int) $_GET['num'];
$req = $pdo->prepare("UPDATE offre_stage SET statut = 'fermee' WHERE num_offre = ?");
$req->execute([$num]);

header("Location: ../admin/offres.php");
exit;
?>
