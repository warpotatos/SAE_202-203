<?php
// traitements/repondre_candidature.php — Accepter / refuser une candidature.
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("maitre_stage");

$idEtudiant = (int) $_GET['etudiant'];
$numOffre   = (int) $_GET['offre'];
$reponse    = $_GET['reponse'];

// On vérifie que l'offre appartient bien à ce maître de stage.
$verif = $pdo->prepare("SELECT 1
                        FROM offre_stage o
                        JOIN maitre_stage m ON m.id_maitre = o.id_maitre
                        WHERE o.num_offre = ? AND m.num_utilisateur = ?");
$verif->execute([$numOffre, $_SESSION['user_id']]);

if ($verif->fetch()) {
    // On choisit le nouveau statut.
    if ($reponse == "accepter") {
        $statut = "acceptee";
    } else {
        $statut = "refusee";
    }
    $maj = $pdo->prepare("UPDATE postulation SET statut = ? WHERE id_etudiant = ? AND num_offre = ?");
    $maj->execute([$statut, $idEtudiant, $numOffre]);
}

header("Location: ../professionnel/candidatures.php");
exit;
?>
