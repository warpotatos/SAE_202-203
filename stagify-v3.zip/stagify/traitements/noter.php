<?php
// traitements/noter.php — Enregistre une note de stage (par l'enseignant).
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("enseignant");

$req = $pdo->prepare("SELECT num_enseignant FROM enseignant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$ens = $req->fetch();
$numEnseignant = $ens['num_enseignant'];

$numStage    = (int) $_POST['num_stage'];
$note        = $_POST['note'];
$date        = $_POST['date'];
$commentaire = $_POST['commentaire'];

// Une note existe-t-elle déjà pour ce stage et cet enseignant ?
$verif = $pdo->prepare("SELECT 1 FROM notation WHERE num_enseignant = ? AND num_stage = ?");
$verif->execute([$numEnseignant, $numStage]);

if ($verif->fetch()) {
    // On met à jour la note existante.
    $maj = $pdo->prepare("UPDATE notation SET note = ?, commentaire = ?, date_notation = ?
                          WHERE num_enseignant = ? AND num_stage = ?");
    $maj->execute([$note, $commentaire, $date, $numEnseignant, $numStage]);
} else {
    // On crée la note.
    $ajout = $pdo->prepare("INSERT INTO notation (num_enseignant, num_stage, note, commentaire, date_notation)
                            VALUES (?, ?, ?, ?, ?)");
    $ajout->execute([$numEnseignant, $numStage, $note, $commentaire, $date]);
}

header("Location: ../enseignant/notes.php");
exit;
?>
