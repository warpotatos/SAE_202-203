<?php
// traitements/postuler.php — Enregistre une candidature.
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("etudiant");

$idOffre   = (int) $_POST['offre'];
$motivation= $_POST['motivation'];
$duree     = $_POST['duree'];

// On retrouve l'id_etudiant de l'utilisateur connecté.
$req = $pdo->prepare("SELECT id_etudiant FROM etudiant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$etudiant = $req->fetch();
$idEtudiant = $etudiant['id_etudiant'];

// A-t-il déjà postulé à cette offre ? (clé primaire id_etudiant + num_offre)
$verif = $pdo->prepare("SELECT 1 FROM postulation WHERE id_etudiant = ? AND num_offre = ?");
$verif->execute([$idEtudiant, $idOffre]);

if (!$verif->fetch()) {
    // Nouvelle candidature.
    $ajout = $pdo->prepare("INSERT INTO postulation (id_etudiant, num_offre, motivation, duree_souhaitee)
                            VALUES (?, ?, ?, ?)");
    $ajout->execute([$idEtudiant, $idOffre, $motivation, $duree]);
}

// On renvoie l'étudiant vers la liste de ses demandes.
header("Location: ../etudiant/candidatures.php");
exit;
?>
