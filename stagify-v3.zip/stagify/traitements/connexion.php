<?php
// traitements/connexion.php — Vérifie les identifiants et ouvre la session.
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";

// On récupère ce que l'utilisateur a tapé.
$login = $_POST['login'];
$motdepasse = $_POST['motdepasse'];

// Pour revenir sur la bonne page en cas d'erreur.
$espace = "etudiant";
if (isset($_POST['espace'])) {
    $espace = $_POST['espace'];
}

// On cherche l'utilisateur dans la base.
$requete = $pdo->prepare("SELECT * FROM utilisateur WHERE login = ?");
$requete->execute([$login]);
$utilisateur = $requete->fetch();

// On vérifie le mot de passe (comparé au mot de passe chiffré stocké).
if ($utilisateur && password_verify($motdepasse, $utilisateur['mot_de_passe'])) {

    // Connexion réussie : on garde les infos en session.
    $_SESSION['user_id'] = $utilisateur['num_utilisateur'];
    $_SESSION['role'] = $utilisateur['role'];

    // Redirection vers le bon espace.
    if ($utilisateur['role'] == "etudiant") {
        header("Location: ../etudiant/dashboard.php");
    } elseif ($utilisateur['role'] == "enseignant") {
        header("Location: ../enseignant/dashboard.php");
    } elseif ($utilisateur['role'] == "maitre_stage") {
        header("Location: ../professionnel/dashboard.php");
    } else {
        header("Location: ../admin/dashboard.php");
    }
    exit;

} else {
    // Échec : on renvoie vers la page de connexion avec un message.
    header("Location: ../connexion_" . $espace . ".php?erreur=1");
    exit;
}
?>
