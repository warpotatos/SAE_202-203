<?php
// traitements/deconnexion.php — Ferme la session.
require_once "../includes/fonctions.php";

// On vide et on détruit la session (voir cours "Gestion de sessions").
session_unset();
session_destroy();

// On revient sur le catalogue public : on peut alors se reconnecter
// avec un autre compte sans fermer la page (lien "Connexion" dans l'en-tête).
header("Location: ../catalogue.php");
exit;
?>
