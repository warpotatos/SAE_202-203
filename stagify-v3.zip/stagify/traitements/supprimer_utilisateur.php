<?php
// traitements/supprimer_utilisateur.php — Supprime un compte (admin).
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("admin");

$num = (int) $_GET['num'];

// On ne se supprime pas soi-même.
if ($num != $_SESSION['user_id']) {
    // La suppression de l'utilisateur supprime aussi ses données liées (ON DELETE CASCADE).
    $req = $pdo->prepare("DELETE FROM utilisateur WHERE num_utilisateur = ?");
    $req->execute([$num]);
}

header("Location: ../admin/utilisateurs.php");
exit;
?>
