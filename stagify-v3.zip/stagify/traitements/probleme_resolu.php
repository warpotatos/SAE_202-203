<?php
// traitements/probleme_resolu.php — Marque un problème comme résolu.
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("enseignant");

$numProb = (int) $_GET['num'];

$maj = $pdo->prepare("UPDATE probleme SET statut = 'resolu' WHERE num_prob = ?");
$maj->execute([$numProb]);

header("Location: ../enseignant/problemes.php");
exit;
?>
