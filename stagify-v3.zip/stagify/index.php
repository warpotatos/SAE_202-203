<?php
// index.php — Accueil public : choix de l'espace pour se connecter.
require_once "includes/fonctions.php";

// Si déjà connecté, on envoie vers le bon tableau de bord.
if (estConnecte()) {
    $role = roleConnecte();
    if ($role == "etudiant")     { header("Location: etudiant/dashboard.php"); exit; }
    if ($role == "enseignant")   { header("Location: enseignant/dashboard.php"); exit; }
    if ($role == "maitre_stage") { header("Location: professionnel/dashboard.php"); exit; }
    if ($role == "admin")        { header("Location: admin/dashboard.php"); exit; }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Accueil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="accueil-public">
        <div class="logo-accueil">
            <img src="img/logo.svg" alt="Stagify" width="72" height="72">
        </div>
        <h1>Bienvenue sur Stagify</h1>
        <p class="intro">La plateforme de gestion des stages. Connectez-vous à votre espace.</p>

        <div class="grille-roles">
            <div class="carte-role">
                <h2>Vous êtes étudiant ?</h2>
                <p>Consultez les offres de stage, postulez et suivez l'avancement de votre stage en temps réel.</p>
                <a class="bouton-principal btn-etudiant" href="connexion_etudiant.php">Connexion</a>
            </div>
            <div class="carte-role">
                <h2>Vous êtes professionnel ?</h2>
                <p>Publiez des offres de stage, gérez vos candidatures et encadrez vos stagiaires.</p>
                <a class="bouton-principal btn-professionnel" href="connexion_professionnel.php">Connexion</a>
            </div>
            <div class="carte-role">
                <h2>Vous êtes enseignant ?</h2>
                <p>Suivez vos étudiants en stage, planifiez vos visites et gérez les soutenances.</p>
                <a class="bouton-principal btn-enseignant" href="connexion_enseignant.php">Connexion</a>
            </div>
        </div>

        <p class="intro" style="margin-top:34px;">Pas de compte ? <a href="inscription.php" style="color:#1565d8;font-weight:700;">Créer un compte</a></p>
    </div>
</body>
</html>
