<?php
// professionnel/stagiaires.php — Stagiaires encadrés par le maître de stage.
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$req = $pdo->prepare("SELECT id_maitre FROM maitre_stage WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$maitre = $req->fetch();

$liste = $pdo->prepare("SELECT e.nom, e.prenom, e.email, s.remuneration, s.duree,
                               o.titre AS poste, s.date_debut, s.date_fin
                        FROM stage s
                        JOIN etudiant e        ON e.id_etudiant = s.id_etudiant
                        LEFT JOIN offre_stage o ON o.num_offre = s.num_offre
                        WHERE s.id_maitre = ?
                        ORDER BY e.nom");
$liste->execute([$maitre['id_maitre']]);
$stagiaires = $liste->fetchAll();

$aujourdhui = date("Y-m-d");

$racine = "../";
$actif = "stagiaires.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Mes stagiaires</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Mes stagiaires</h2>
    <table class="tableau">
        <thead><tr><th>NOM / PRÉNOM</th><th>RÉMUNÉRATION</th><th>EMAIL</th><th>POSTE</th><th>PÉRIODE</th><th>STATUT</th></tr></thead>
        <tbody>
        <?php foreach ($stagiaires as $s) { ?>
            <tr>
                <td><?php echo e($s['nom'] . " " . $s['prenom']); ?></td>
                <td><?php echo $s['remuneration'] ? e($s['remuneration']) : "Stage non rémunéré"; ?></td>
                <td><?php echo e($s['email']); ?></td>
                <td><?php echo $s['poste'] ? e($s['poste']) : "—"; ?></td>
                <td><?php echo e($s['duree']); ?></td>
                <td>
                    <?php
                    if ($s['date_debut'] && $s['date_debut'] > $aujourdhui) {
                        echo '<span class="pastille pastille-avenir">Stage à venir</span>';
                    } elseif ($s['date_fin'] && $s['date_fin'] < $aujourdhui) {
                        echo '<span class="pastille pastille-aucun">Terminé</span>';
                    } else {
                        echo '<span class="pastille pastille-encours">Stage en cours</span>';
                    }
                    ?>
                </td>
            </tr>
        <?php } ?>
        <?php if (count($stagiaires) == 0) { ?>
            <tr><td colspan="6" style="color:#6b7785;">Aucun stagiaire pour le moment.</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
