<?php
// professionnel/notes.php — Appréciation et note des stagiaires (par le maître).
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$req = $pdo->prepare("SELECT id_maitre FROM maitre_stage WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$maitre = $req->fetch();

// Les stages encadrés par ce maître (pour le menu + le tableau).
$liste = $pdo->prepare("SELECT s.num_stage, e.nom, e.prenom, s.appreciation, s.note_maitre
                        FROM stage s
                        JOIN etudiant e ON e.id_etudiant = s.id_etudiant
                        WHERE s.id_maitre = ?
                        ORDER BY e.nom");
$liste->execute([$maitre['id_maitre']]);
$stagiaires = $liste->fetchAll();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Note &amp; Évaluation</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <form class="bloc" action="../traitements/evaluer_stagiaire.php" method="post">
        <h2>Évaluer un stagiaire</h2>
        <div class="grille-2">
            <div>
                <label style="font-weight:700;">Stagiaire</label>
                <select name="num_stage" required style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;">
                    <option value="">Choisir</option>
                    <?php foreach ($stagiaires as $st) { ?>
                        <option value="<?php echo $st['num_stage']; ?>"><?php echo e($st['nom'] . " " . $st['prenom']); ?></option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label style="font-weight:700;">Note /20</label>
                <input type="number" name="note" min="0" max="20" step="0.5" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;">
            </div>
        </div>
        <label style="font-weight:700;display:block;margin-top:14px;">Appréciation</label>
        <textarea name="appreciation" rows="4" placeholder="Appréciation du stagiaire ..." style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:8px;padding:12px;"></textarea>
        <div style="text-align:right;margin-top:16px;"><button type="submit" class="bouton-postuler">Enregistrer</button></div>
    </form>

    <table class="tableau">
        <thead><tr><th>STAGIAIRE</th><th>APPRÉCIATION</th><th>NOTE</th></tr></thead>
        <tbody>
        <?php foreach ($stagiaires as $s) { ?>
            <tr>
                <td><?php echo e($s['nom'] . " " . $s['prenom']); ?></td>
                <td><?php echo $s['appreciation'] ? e($s['appreciation']) : "—"; ?></td>
                <td><?php echo $s['note_maitre'] !== null ? e($s['note_maitre']) . "/20" : "—"; ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
