<?php
// messagerie.php — Messagerie simple entre utilisateurs (tous rôles).
require_once "includes/fonctions.php";
require_once "config/connexion.php";

// Il faut être connecté (peu importe le rôle).
if (!estConnecte()) {
    header("Location: index.php");
    exit;
}
$moi = $_SESSION['user_id'];

// Liste des autres utilisateurs (= les conversations possibles).
$contacts = $pdo->prepare("SELECT num_utilisateur, prenom, nom, role
                           FROM v_utilisateur_nom
                           WHERE num_utilisateur != ?
                           ORDER BY nom");
$contacts->execute([$moi]);
$contacts = $contacts->fetchAll();

// Avec qui je discute (num_utilisateur passé dans l'URL).
$avec = 0;
if (isset($_GET['avec'])) {
    $avec = (int) $_GET['avec'];
}

$messages = array();
$contactActuel = null;
if ($avec != 0) {
    // Nom du contact courant.
    $c = $pdo->prepare("SELECT prenom, nom FROM v_utilisateur_nom WHERE num_utilisateur = ?");
    $c->execute([$avec]);
    $contactActuel = $c->fetch();

    // Les messages échangés entre lui et moi.
    $m = $pdo->prepare("SELECT * FROM message
                        WHERE (expediteur = ? AND destinataire = ?)
                           OR (expediteur = ? AND destinataire = ?)
                        ORDER BY date_envoi");
    $m->execute([$moi, $avec, $avec, $moi]);
    $messages = $m->fetchAll();

    // On marque comme lus les messages qu'il m'a envoyés.
    $lu = $pdo->prepare("UPDATE message SET lu = 1 WHERE expediteur = ? AND destinataire = ?");
    $lu->execute([$avec, $moi]);
}

$racine = "";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Messagerie</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div class="contenu">
    <div class="messagerie">
        <div class="liste-contacts">
            <?php foreach ($contacts as $contact) { ?>
                <a class="contact <?php if ($contact['num_utilisateur'] == $avec) echo 'actif'; ?>"
                   href="messagerie.php?avec=<?php echo $contact['num_utilisateur']; ?>">
                    <strong><?php echo e($contact['prenom'] . " " . $contact['nom']); ?></strong>
                    <small><?php echo e($contact['role']); ?></small>
                </a>
            <?php } ?>
        </div>

        <div class="fil-messages">
            <?php if ($contactActuel == null) { ?>
                <p style="color:#6b7785;padding:20px;">Choisissez une conversation à gauche.</p>
            <?php } else { ?>
                <div class="fil-entete"><?php echo e($contactActuel['prenom'] . " " . $contactActuel['nom']); ?></div>
                <div class="fil-corps">
                    <?php foreach ($messages as $msg) { ?>
                        <div class="bulle <?php echo ($msg['expediteur'] == $moi) ? 'moi' : 'autre'; ?>">
                            <?php echo e($msg['contenu']); ?>
                        </div>
                    <?php } ?>
                </div>
                <form class="fil-envoi" action="traitements/envoyer_message.php" method="post">
                    <input type="hidden" name="destinataire" value="<?php echo $avec; ?>">
                    <input type="text" name="contenu" placeholder="Votre message ..." required>
                    <button type="submit" class="bouton-rechercher">Envoyer</button>
                </form>
            <?php } ?>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
