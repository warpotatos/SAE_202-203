# Stagify — version refonte (niveau BUT MMI 1re année)

Plateforme de gestion de stages en **PHP procédural + PDO + MySQL**.

## Installation (XAMPP)

1. Copier le dossier `stagify/` dans `xampp/htdocs/`.
2. Démarrer **Apache** et **MySQL** dans XAMPP.
3. Importer la base : ouvrir phpMyAdmin → onglet *Importer* → choisir `database.sql`.
   (La base `stagify` et toutes les tables sont créées automatiquement.)
4. Ouvrir le site : `http://localhost/stagify/`

La connexion à la base se règle dans `config/connexion.php` (par défaut `root` sans mot de passe, comme XAMPP).

## Comptes de démonstration

Mot de passe pour tous : **password**

| Rôle          | Identifiant     |
|---------------|-----------------|
| Étudiant      | `jean.dupont`   |
| Étudiant      | `alice.martin`  |
| Enseignant    | `marie.bernard` |
| Professionnel | `marc.leblanc`  |
| Admin         | `admin`         |

> Remarque : le mot de passe `password` ne respecte pas la nouvelle règle (8 caractères + majuscule + chiffre). Cette règle s'applique seulement aux **nouvelles inscriptions**.

## Ce qui est fait

**Public** : accueil + choix de rôle, 3 connexions, 3 inscriptions, catalogue, recherche avancée, entreprises, détail d'offre.

**Espace étudiant** (`etudiant/`) : dashboard, liste/recherche d'offres, détail, postuler, mes demandes, profil.

**Espace enseignant** (`enseignant/`) : dashboard (tuiles), mes étudiants, jury/soutenances, problèmes (avec « marquer résolu »), note & évaluation (saisie + historique), profil.

**Espace professionnel** (`professionnel/`) : dashboard (tuiles), mes stagiaires, demandes reçues (accepter/refuser), note & évaluation du stagiaire, créer une offre, profil.

**Espace admin** (`admin/`) : dashboard (tuiles), gestion des utilisateurs (liste + suppression en cascade), gestion des offres (fermer / supprimer), statistiques (compteurs), profil.

**Commun** : messagerie entre tous les rôles, en-tête/menu adaptés au rôle, barre de recherche (Localisation = régions ; liens Recherche avancée / Entreprises).

**Traitements** : connexion, inscription, déconnexion, postuler, envoyer_message, noter, probleme_resolu, repondre_candidature, evaluer_stagiaire, creer_offre.

## Colonnes ajoutées à la base (réimporter `database.sql`)

- `postulation` : `motivation`, `duree_souhaitee`
- `stage` : `remuneration`, `appreciation`, `note_maitre`
- `offre_stage` : `competences`, `remuneration`
- Données de démo : un stage (Jean Dupont chez TechCorp), une soutenance, une visite, un problème, des candidatures.

## À faire ensuite (optionnel)

- Upload réel du CV (le champ existe mais le fichier n'est pas encore stocké).

## Notions utilisées (vues en cours)

Sessions (`session_start`, `$_SESSION`, `session_destroy`), `header('Location: …')`,
PDO (`prepare` / `execute` / `fetch`), `password_hash` / `password_verify`,
`include` / `require`, formulaires `$_POST`.
