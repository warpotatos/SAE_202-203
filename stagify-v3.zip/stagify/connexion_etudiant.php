<?php
// connexion_etudiant.php — Page de connexion (Espace étudiant).
require_once "includes/fonctions.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Connexion</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="page-centre">
        <div class="carte-auth">
            <div class="entete-auth entete-etudiant">Espace étudiant</div>
            <div class="corps-auth">

                <?php if (isset($_GET['erreur'])) { ?>
                    <div class="erreur">Identifiant ou mot de passe incorrect.</div>
                <?php } ?>

                <form action="traitements/connexion.php" method="post">
                    <input type="hidden" name="espace" value="etudiant">
                    <label>Identifiant :</label>
                    <div class="champ-icone">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
                        <input type="text" name="login" required>
                    </div>

                    <label>Mot de passe :</label>
                    <div class="champ-icone">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>
                        <input type="password" name="motdepasse" required>
                    </div>

                    <button type="submit" class="bouton-principal btn-etudiant">→ Se connecter</button>
                </form>

                <div class="liens-auth">
                    <a href="#">Mot de passe oublié</a>
                    <a href="index.php">← Retour</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
