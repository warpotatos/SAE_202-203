<?php
require_once "includes/fonctions.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Créer un compte</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="accueil-public">
        <div class="logo-accueil">
            <img src="img/logo.svg" alt="Stagify" width="72" height="72">
        </div>
        <h1>Créer votre compte</h1>
        <p class="intro">Choisissez le type de compte à créer.</p>

        <div class="grille-roles">
            <div class="carte-role">
                <h2>Vous êtes étudiant ?</h2>
                <p>Accédez aux offres de stage et gérez votre parcours.</p>
                <a class="bouton-principal btn-etudiant" href="inscription_etudiant.php">Choisir</a>
            </div>
            <div class="carte-role">
                <h2>Vous êtes professionnel ?</h2>
                <p>Publiez des offres et encadrez vos stagiaires.</p>
                <a class="bouton-principal btn-professionnel" href="inscription_professionnel.php">Choisir</a>
            </div>
            <div class="carte-role">
                <h2>Vous êtes enseignant ?</h2>
                <p>Suivez vos étudiants et gérez les soutenances.</p>
                <a class="bouton-principal btn-enseignant" href="inscription_enseignant.php">Choisir</a>
            </div>
        </div>

        <p class="intro" style="margin-top:34px;"><a href="index.php" style="color:#1565d8;font-weight:700;">← Retour</a></p>
    </div>
</body>
</html>
