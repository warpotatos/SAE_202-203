<?php
require_once "includes/fonctions.php";
require_once "config/connexion.php";

$poste     = isset($_GET['poste'])     ? $_GET['poste']     : "";
$region    = isset($_GET['region'])    ? $_GET['region']    : "";
$entreprise= isset($_GET['entreprise'])? $_GET['entreprise']: "";

$sql = "SELECT o.num_offre, o.titre, o.duree, e.nom AS entreprise
        FROM offre_stage o
        JOIN entreprise e ON e.id_entreprise = o.id_entreprise
        WHERE o.statut = 'ouverte'";
$valeurs = array();

if ($poste != "") {
    $sql .= " AND o.titre LIKE ?";
    $valeurs[] = "%" . $poste . "%";
}
if ($region != "") {
    $sql .= " AND e.ville LIKE ?";
    $valeurs[] = "%" . $region . "%";
}
if ($entreprise != "") {
    $sql .= " AND e.nom = ?";
    $valeurs[] = $entreprise;
}
$sql .= " ORDER BY o.date_publication DESC";

$requete = $pdo->prepare($sql);
$requete->execute($valeurs);
$offres = $requete->fetchAll();

$listeEntreprises = $pdo->query("SELECT nom FROM entreprise ORDER BY nom")->fetchAll();

$regions = array("Auvergne-Rhône-Alpes","Bourgogne-Franche-Comté","Bretagne","Centre-Val de Loire",
"Corse","Grand Est","Hauts-de-France","Île-de-France","Normandie","Nouvelle-Aquitaine",
"Occitanie","Pays de la Loire","Provence-Alpes-Côte d'Azur");

$racine = "";
$actif = "catalogue.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Recherche avancée</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div class="recherche-page">
    <form class="panneau-filtres" action="recherche.php" method="get">
        <h2>🔎 Recherche avancée</h2>

        <label>Poste / mots clés</label>
        <input type="text" name="poste" value="<?php echo e($poste); ?>">

        <label>Localisation</label>
        <select name="region">
            <option value="">Toutes les régions</option>
            <?php foreach ($regions as $r) { ?>
                <option value="<?php echo e($r); ?>" <?php if ($region == $r) echo 'selected'; ?>><?php echo e($r); ?></option>
            <?php } ?>
        </select>

        <label>Entreprise</label>
        <select name="entreprise">
            <option value="">Toutes les entreprises</option>
            <?php foreach ($listeEntreprises as $ent) { ?>
                <option value="<?php echo e($ent['nom']); ?>" <?php if ($entreprise == $ent['nom']) echo 'selected'; ?>><?php echo e($ent['nom']); ?></option>
            <?php } ?>
        </select>

        <button type="submit" class="bouton-rechercher" style="margin-top:18px;">Rechercher</button>
    </form>

    <div class="resultats">
        <div class="nombre" style="font-size:30px;"><?php echo count($offres); ?><span>offres correspondantes</span></div>
        <div class="grille-offres" style="grid-template-columns:repeat(2,1fr);margin-top:18px;">
            <?php foreach ($offres as $offre) { ?>
                <div class="carte-offre">
                    <h3><?php echo e($offre['titre']); ?></h3>
                    <div class="entreprise"><?php echo e($offre['entreprise']); ?></div>
                    <div class="bas">
                        <div><small>Description du poste</small><small>Durée : <?php echo e($offre['duree']); ?></small></div>
                        <a class="plus" href="offre.php?id=<?php echo $offre['num_offre']; ?>">+</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
