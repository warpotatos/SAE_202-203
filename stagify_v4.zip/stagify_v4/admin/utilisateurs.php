<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("admin");

$utilisateurs = $pdo->query("SELECT u.num_utilisateur, u.role, u.email, u.date_creation,
                                    COALESCE(e.prenom, ens.prenom, ms.prenom, a.prenom) AS prenom,
                                    COALESCE(e.nom, ens.nom, ms.nom, a.nom) AS nom
                             FROM utilisateur u
                             LEFT JOIN etudiant     e   ON e.num_utilisateur   = u.num_utilisateur
                             LEFT JOIN enseignant   ens ON ens.num_utilisateur = u.num_utilisateur
                             LEFT JOIN maitre_stage ms  ON ms.num_utilisateur  = u.num_utilisateur
                             LEFT JOIN admin        a   ON a.num_utilisateur   = u.num_utilisateur
                             ORDER BY u.date_creation DESC")->fetchAll();

$racine = "../";
$actif = "utilisateurs.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Utilisateurs</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Gestion des utilisateurs (<?php echo count($utilisateurs); ?>)</h2>
    <table class="tableau">
        <thead><tr><th>NOM</th><th>PRÉNOM</th><th>RÔLE</th><th>EMAIL</th><th>CRÉÉ LE</th><th>ACTION</th></tr></thead>
        <tbody>
        <?php foreach ($utilisateurs as $u) { ?>
            <tr>
                <td><?php echo e($u['nom']); ?></td>
                <td><?php echo e($u['prenom']); ?></td>
                <td><span class="pastille pastille-encours" style="text-transform:capitalize;"><?php echo e(str_replace("_", " ", $u['role'])); ?></span></td>
                <td><?php echo e($u['email']); ?></td>
                <td><?php echo e(substr($u['date_creation'], 0, 10)); ?></td>
                <td>
                    <?php if ($u['num_utilisateur'] == $_SESSION['user_id']) { ?>
                        <span style="color:#6b7785;">(vous)</span>
                    <?php } else { ?>
                        <a href="../traitements/supprimer_utilisateur.php?num=<?php echo $u['num_utilisateur']; ?>"
                           onclick="return confirm('Supprimer ce compte et toutes ses données ?');"
                           style="color:#b42318;font-weight:700;">Supprimer</a>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
