<?php
require_once "includes/fonctions.php";
require_once "config/connexion.php";

$entreprises = $pdo->query("SELECT e.id_entreprise, e.nom, e.ville,
                                   COUNT(o.num_offre) AS nb_offres
                            FROM entreprise e
                            LEFT JOIN offre_stage o
                                   ON o.id_entreprise = e.id_entreprise AND o.statut = 'ouverte'
                            GROUP BY e.id_entreprise, e.nom, e.ville
                            ORDER BY e.nom")->fetchAll();

$racine = "";
$actif = "catalogue.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Entreprises</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div class="contenu">
    <h2 class="titre-section">Entreprises partenaires</h2>
    <div class="grille-offres">
        <?php foreach ($entreprises as $ent) { ?>
            <div class="carte-offre">
                <h3><?php echo e($ent['nom']); ?></h3>
                <div class="entreprise"><?php echo e($ent['ville']); ?></div>
                <div class="bas">
                    <div><small><?php echo $ent['nb_offres']; ?> offre(s) ouverte(s)</small></div>
                    <a class="plus" href="recherche.php?entreprise=<?php echo urlencode($ent['nom']); ?>" title="Voir les offres">+</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
