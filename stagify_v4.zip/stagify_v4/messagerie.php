<?php
require_once "includes/fonctions.php";
require_once "config/connexion.php";

if (!estConnecte()) {
    header("Location: index.php");
    exit;
}
$moi = $_SESSION['user_id'];

$contacts = $pdo->prepare("SELECT u.num_utilisateur, u.role,
                               COALESCE(e.prenom, ens.prenom, ms.prenom, a.prenom) AS prenom,
                               COALESCE(e.nom, ens.nom, ms.nom, a.nom) AS nom
                           FROM utilisateur u
                           LEFT JOIN etudiant     e   ON e.num_utilisateur   = u.num_utilisateur
                           LEFT JOIN enseignant   ens ON ens.num_utilisateur = u.num_utilisateur
                           LEFT JOIN maitre_stage ms  ON ms.num_utilisateur  = u.num_utilisateur
                           LEFT JOIN admin        a   ON a.num_utilisateur   = u.num_utilisateur
                           WHERE u.num_utilisateur != ?
                           ORDER BY nom");
$contacts->execute([$moi]);
$contacts = $contacts->fetchAll();

$avec = 0;
if (isset($_GET['avec'])) {
    $avec = (int) $_GET['avec'];
}

$messages = array();
$contactActuel = null;
if ($avec != 0) {
    $c = $pdo->prepare("SELECT COALESCE(e.prenom, ens.prenom, ms.prenom, a.prenom) AS prenom,
                               COALESCE(e.nom, ens.nom, ms.nom, a.nom) AS nom
                        FROM utilisateur u
                        LEFT JOIN etudiant     e   ON e.num_utilisateur   = u.num_utilisateur
                        LEFT JOIN enseignant   ens ON ens.num_utilisateur = u.num_utilisateur
                        LEFT JOIN maitre_stage ms  ON ms.num_utilisateur  = u.num_utilisateur
                        LEFT JOIN admin        a   ON a.num_utilisateur   = u.num_utilisateur
                        WHERE u.num_utilisateur = ?");
    $c->execute([$avec]);
    $contactActuel = $c->fetch();

    $m = $pdo->prepare("SELECT * FROM message
                        WHERE (expediteur = ? AND destinataire = ?)
                           OR (expediteur = ? AND destinataire = ?)
                        ORDER BY date_envoi");
    $m->execute([$moi, $avec, $avec, $moi]);
    $messages = $m->fetchAll();

    $lu = $pdo->prepare("UPDATE message SET lu = 1 WHERE expediteur = ? AND destinataire = ?");
    $lu->execute([$avec, $moi]);
}

$racine = "";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Messagerie</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div class="contenu">
    <div class="messagerie">
        <div class="liste-contacts">
            <?php foreach ($contacts as $contact) { ?>
                <a class="contact <?php if ($contact['num_utilisateur'] == $avec) echo 'actif'; ?>"
                   href="messagerie.php?avec=<?php echo $contact['num_utilisateur']; ?>">
                    <strong><?php echo e($contact['prenom'] . " " . $contact['nom']); ?></strong>
                    <small><?php echo e($contact['role']); ?></small>
                </a>
            <?php } ?>
        </div>

        <div class="fil-messages">
            <?php if ($contactActuel == null) { ?>
                <p style="color:#6b7785;padding:20px;">Choisissez une conversation à gauche.</p>
            <?php } else { ?>
                <div class="fil-entete"><?php echo e($contactActuel['prenom'] . " " . $contactActuel['nom']); ?></div>
                <div class="fil-corps">
                    <?php foreach ($messages as $msg) { ?>
                        <div class="bulle <?php echo ($msg['expediteur'] == $moi) ? 'moi' : 'autre'; ?>">
                            <?php echo e($msg['contenu']); ?>
                        </div>
                    <?php } ?>
                </div>
                <form class="fil-envoi" action="traitements/envoyer_message.php" method="post">
                    <input type="hidden" name="destinataire" value="<?php echo $avec; ?>">
                    <input type="text" name="contenu" placeholder="Votre message ..." required>
                    <button type="submit" class="bouton-rechercher">Envoyer</button>
                </form>
            <?php } ?>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

</body>
</html>
