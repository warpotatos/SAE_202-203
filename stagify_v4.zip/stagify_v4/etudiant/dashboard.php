<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("etudiant");

$req = $pdo->prepare("SELECT * FROM etudiant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$etudiant = $req->fetch();

$reqDemandes = $pdo->prepare("SELECT p.date_postulation, p.statut, o.titre, o.duree, e.nom AS entreprise
                              FROM postulation p
                              JOIN offre_stage o ON o.num_offre = p.num_offre
                              JOIN entreprise e  ON e.id_entreprise = o.id_entreprise
                              WHERE p.id_etudiant = ?
                              ORDER BY p.date_postulation DESC LIMIT 5");
$reqDemandes->execute([$etudiant['id_etudiant']]);
$demandes = $reqDemandes->fetchAll();

$offres = $pdo->query("SELECT o.num_offre, o.titre, o.duree, e.nom AS entreprise
                       FROM offre_stage o
                       JOIN entreprise e ON e.id_entreprise = o.id_entreprise
                       WHERE o.statut = 'ouverte'
                       ORDER BY o.date_publication DESC LIMIT 6")->fetchAll();

$racine = "../";
$versRacine = "../";
$actif = "dashboard.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Accueil étudiant</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include "../includes/header.php"; ?>
<div class="contenu"><?php include "../includes/barre_recherche.php"; ?></div>

<div class="contenu">
    <div class="bloc">
        <h2>Mes demandes</h2>
        <?php if (count($demandes) == 0) { ?>
            <p style="color:#6b7785;">Vous n'avez pas encore postulé à une offre.</p>
        <?php } else { ?>
            <?php foreach ($demandes as $d) { ?>
                <div class="ligne-demande">
                    <span><?php echo e($d['titre']); ?></span>
                    <span class="date"><?php echo e($d['date_postulation']); ?></span>
                    <span><?php echo e($d['entreprise']); ?></span>
                    <span><?php echo e($d['duree']); ?></span>
                    <?php echo pastilleStatut($d['statut']); ?>
                </div>
            <?php } ?>
        <?php } ?>
    </div>

    <h2 class="titre-section">Offres récentes</h2>
    <div class="grille-offres">
        <?php foreach ($offres as $offre) { ?>
            <div class="carte-offre">
                <h3><?php echo e($offre['titre']); ?></h3>
                <div class="entreprise"><?php echo e($offre['entreprise']); ?></div>
                <div class="bas">
                    <div><small>Description du poste</small><small>Durée : <?php echo e($offre['duree']); ?></small></div>
                    <a class="plus" href="../offre.php?id=<?php echo $offre['num_offre']; ?>">+</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php include "../includes/footer.php"; ?>

</body>
</html>
