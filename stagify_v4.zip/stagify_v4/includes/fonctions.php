<?php

session_start();

function e($texte) {
    return htmlspecialchars($texte);
}

function estConnecte() {
    return isset($_SESSION['user_id']);
}

function roleConnecte() {
    if (isset($_SESSION['role'])) {
        return $_SESSION['role'];
    }
    return "";
}

function pastilleStatut($statut) {
    if ($statut == "en_attente") {
        return '<span class="pastille pastille-attente">En attente ...</span>';
    } elseif ($statut == "acceptee") {
        return '<span class="pastille pastille-encours">Acceptée</span>';
    } elseif ($statut == "refusee") {
        return '<span class="pastille pastille-refus">Refus</span>';
    }
    return '<span class="pastille pastille-aucun">—</span>';
}

function proteger($role) {
    if (!estConnecte() || $_SESSION['role'] != $role) {
        header("Location: ../index.php");
        exit;
    }
}
?>
