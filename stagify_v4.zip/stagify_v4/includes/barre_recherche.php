<?php

if (!isset($versRacine)) { $versRacine = ""; }

$regions = array(
    "Auvergne-Rhône-Alpes", "Bourgogne-Franche-Comté", "Bretagne",
    "Centre-Val de Loire", "Corse", "Grand Est", "Hauts-de-France",
    "Île-de-France", "Normandie", "Nouvelle-Aquitaine", "Occitanie",
    "Pays de la Loire", "Provence-Alpes-Côte d'Azur"
);
?>
<form class="recherche" action="<?php echo $versRacine; ?>recherche.php" method="get">
    <div class="recherche-haut">
        <div class="recherche-champ">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg>
            <input type="text" name="poste" placeholder="Poste recherché, mots clés, ...">
        </div>
        <div class="recherche-champ">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-5.7 7-11a7 7 0 0 0-14 0c0 5.3 7 11 7 11"/><circle cx="12" cy="10" r="2.5"/></svg>
            <select name="region">
                <option value="">Localisation</option>
                <?php foreach ($regions as $region) { ?>
                    <option value="<?php echo e($region); ?>"><?php echo e($region); ?></option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="recherche-bas">
        <div class="nombre">50 000<span>offres disponibles</span></div>
        <a class="lien" href="<?php echo $versRacine; ?>recherche.php">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h10M4 12h16M4 17h7"/></svg> Recherche avancée
        </a>
        <a class="lien" href="<?php echo $versRacine; ?>entreprises.php">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5"/></svg> Entreprises
        </a>
        <button type="submit" class="bouton-rechercher">Rechercher
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
        </button>
    </div>
</form>
