<?php

$hote = "localhost";
$base = "stagify";
$utilisateur = "root";
$motdepasse = "";

try {
    $pdo = new PDO("mysql:host=$hote;dbname=$base;charset=utf8mb4", $utilisateur, $motdepasse);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
    exit;
}
?>
