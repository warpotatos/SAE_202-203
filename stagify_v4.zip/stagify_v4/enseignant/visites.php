<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("enseignant");

$req = $pdo->prepare("SELECT num_enseignant FROM enseignant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$ens = $req->fetch();

$liste = $pdo->prepare("SELECT e.nom, e.prenom, so.date, so.heures,
                               j.membres_jury, so.note_rapport, so.note_oral,
                               ent.nom AS entreprise
                        FROM soutenance so
                        JOIN stage s        ON s.num_stage = so.num_stage
                        JOIN etudiant e     ON e.id_etudiant = s.id_etudiant
                        JOIN entreprise ent ON ent.id_entreprise = s.id_entreprise
                        LEFT JOIN jury j    ON j.num_jury = so.num_jury
                        WHERE e.num_enseignant_ref = ?
                        ORDER BY so.date");
$liste->execute([$ens['num_enseignant']]);
$soutenances = $liste->fetchAll();

$racine = "../";
$actif = "visites.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Jury / Soutenance</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Jury / Soutenance</h2>
    <table class="tableau">
        <thead><tr><th>ÉTUDIANT</th><th>DATE</th><th>HEURE</th><th>JURY</th><th>NOTE</th><th>NOTE ORAL</th><th>STAGE</th></tr></thead>
        <tbody>
        <?php foreach ($soutenances as $s) { ?>
            <tr>
                <td><?php echo e($s['nom'] . " " . $s['prenom']); ?></td>
                <td><?php echo e($s['date']); ?></td>
                <td><?php echo e(substr($s['heures'], 0, 5)); ?></td>
                <td><?php echo e($s['membres_jury'] ? $s['membres_jury'] : "à définir"); ?></td>
                <td><?php echo $s['note_rapport'] !== null ? e($s['note_rapport']) : "—"; ?></td>
                <td><?php echo $s['note_oral'] !== null ? e($s['note_oral']) : "—"; ?></td>
                <td><?php echo e($s['entreprise']); ?></td>
            </tr>
        <?php } ?>
        <?php if (count($soutenances) == 0) { ?>
            <tr><td colspan="7" style="color:#6b7785;">Aucune soutenance planifiée.</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
