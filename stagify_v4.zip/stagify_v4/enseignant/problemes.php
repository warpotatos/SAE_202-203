<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("enseignant");

$req = $pdo->prepare("SELECT num_enseignant FROM enseignant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$ens = $req->fetch();

$liste = $pdo->prepare("SELECT p.num_prob, e.nom, e.prenom, ent.nom AS entreprise,
                               p.date_incident, p.description, p.statut
                        FROM probleme p
                        JOIN stage s        ON s.num_stage = p.num_stage
                        JOIN etudiant e     ON e.id_etudiant = p.id_etudiant
                        JOIN entreprise ent ON ent.id_entreprise = s.id_entreprise
                        WHERE e.num_enseignant_ref = ?
                        ORDER BY p.date_incident DESC");
$liste->execute([$ens['num_enseignant']]);
$problemes = $liste->fetchAll();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Problème élève</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Problème élève</h2>
    <table class="tableau">
        <thead><tr><th>ÉTUDIANT</th><th>ENTREPRISE</th><th>DATE INCIDENT</th><th>DESCRIPTION</th><th>STATUT</th><th>ACTION</th></tr></thead>
        <tbody>
        <?php foreach ($problemes as $p) { ?>
            <tr>
                <td><?php echo e($p['nom'] . " " . $p['prenom']); ?></td>
                <td><?php echo e($p['entreprise']); ?></td>
                <td><?php echo e($p['date_incident']); ?></td>
                <td><?php echo e($p['description']); ?></td>
                <td>
                    <?php if ($p['statut'] == 'resolu') { ?><span class="pastille pastille-encours">Résolu</span>
                    <?php } elseif ($p['statut'] == 'en_cours') { ?><span class="pastille pastille-attente">En cours</span>
                    <?php } else { ?><span class="pastille pastille-refus">Ouvert</span><?php } ?>
                </td>
                <td>
                    <?php if ($p['statut'] != 'resolu') { ?>
                        <a href="../traitements/probleme_resolu.php?num=<?php echo $p['num_prob']; ?>" style="color:#1565d8;font-weight:700;">Marquer résolu</a>
                    <?php } else { ?>—<?php } ?>
                </td>
            </tr>
        <?php } ?>
        <?php if (count($problemes) == 0) { ?>
            <tr><td colspan="6" style="color:#6b7785;">Aucun problème signalé.</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
