<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$req = $pdo->prepare("SELECT m.id_maitre, e.ville
                      FROM maitre_stage m
                      LEFT JOIN entreprise e ON e.id_entreprise = m.id_entreprise
                      WHERE m.num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$maitre = $req->fetch();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Créer une offre</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <form class="bloc" action="../traitements/creer_offre.php" method="post">
        <div class="grille-2">
            <div>
                <label style="font-weight:800;font-size:18px;">Intitulé de l'offre</label>
                <input type="text" name="titre" required style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;">
            </div>
            <div>
                <label style="font-weight:800;font-size:18px;">Localisation</label>
                <input type="text" name="localisation" value="<?php echo e($maitre['ville']); ?>" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;">
            </div>
        </div>

        <label style="font-weight:800;font-size:18px;display:block;margin-top:18px;">Description</label>
        <textarea name="description" rows="4" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;"></textarea>

        <label style="font-weight:800;font-size:18px;display:block;margin-top:18px;">Compétences requises</label>
        <textarea name="competences" rows="3" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;"></textarea>

        <div class="grille-2" style="margin-top:18px;">
            <div>
                <label style="font-weight:800;font-size:18px;">Rémunération</label>
                <input type="text" name="remuneration" placeholder="ex : 700€/mois" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;">
            </div>
            <div>
                <label style="font-weight:800;font-size:18px;">Durée</label>
                <input type="text" name="duree" placeholder="ex : 6 mois" style="width:100%;background:var(--champ);border:1px solid #cfe8f5;border-radius:10px;padding:12px;margin-top:8px;">
            </div>
        </div>

        <div style="text-align:right;margin-top:24px;"><button type="submit" class="bouton-postuler">Publier</button></div>
    </form>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
