<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$req = $pdo->prepare("SELECT id_maitre FROM maitre_stage WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$maitre = $req->fetch();

$liste = $pdo->prepare("SELECT p.id_etudiant, p.num_offre, p.date_postulation, p.statut,
                               p.duree_souhaitee, e.nom, e.prenom, e.email, o.titre
                        FROM postulation p
                        JOIN offre_stage o ON o.num_offre = p.num_offre
                        JOIN etudiant e    ON e.id_etudiant = p.id_etudiant
                        WHERE o.id_maitre = ?
                        ORDER BY p.date_postulation DESC");
$liste->execute([$maitre['id_maitre']]);
$demandes = $liste->fetchAll();

$racine = "../";
$actif = "candidatures.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Demandes reçues</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <h2 class="titre-section">Demandes reçues</h2>
    <table class="tableau">
        <thead><tr><th>ÉTUDIANT</th><th>EMAIL</th><th>OFFRE</th><th>DATE</th><th>DURÉE</th><th>STATUT</th><th>ACTION</th></tr></thead>
        <tbody>
        <?php foreach ($demandes as $d) { ?>
            <tr>
                <td><?php echo e($d['nom'] . " " . $d['prenom']); ?></td>
                <td><?php echo e($d['email']); ?></td>
                <td><?php echo e($d['titre']); ?></td>
                <td><?php echo e($d['date_postulation']); ?></td>
                <td><?php echo e($d['duree_souhaitee']); ?></td>
                <td><?php echo pastilleStatut($d['statut']); ?></td>
                <td>
                    <?php if ($d['statut'] == 'en_attente') { ?>
                        <a href="../traitements/repondre_candidature.php?etudiant=<?php echo $d['id_etudiant']; ?>&offre=<?php echo $d['num_offre']; ?>&reponse=accepter" style="color:#0c7c8c;font-weight:700;">Accepter</a>
                        &nbsp;|&nbsp;
                        <a href="../traitements/repondre_candidature.php?etudiant=<?php echo $d['id_etudiant']; ?>&offre=<?php echo $d['num_offre']; ?>&reponse=refuser" style="color:#b42318;font-weight:700;">Refuser</a>
                    <?php } else { ?>—<?php } ?>
                </td>
            </tr>
        <?php } ?>
        <?php if (count($demandes) == 0) { ?>
            <tr><td colspan="7" style="color:#6b7785;">Aucune candidature reçue.</td></tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
