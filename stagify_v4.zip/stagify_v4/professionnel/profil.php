<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$req = $pdo->prepare("SELECT m.*, e.nom AS entreprise, e.ville
                      FROM maitre_stage m
                      LEFT JOIN entreprise e ON e.id_entreprise = m.id_entreprise
                      WHERE m.num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$m = $req->fetch();

$racine = "../";
$actif = "";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Mon profil</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu">
    <div class="profil-bloc">
        <div class="profil-bande">
            <div>
                <div class="profil-label">Entreprise</div>
                <div class="champ-bloc"><?php echo e($m['entreprise']); ?> — <?php echo e($m['ville']); ?></div>
            </div>
            <div class="profil-nom"><span><?php echo e($m['nom']); ?></span><span><?php echo e($m['prenom']); ?></span></div>
            <div class="profil-avatar"><svg viewBox="0 0 24 24" width="60" height="60" fill="none" stroke="#7fb6d6" stroke-width="1.6"><circle cx="12" cy="8.5" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg></div>
        </div>
        <div class="grille-2" style="margin-top:18px;">
            <div><div class="profil-label">Poste</div><div class="champ-bloc petit"><?php echo e($m['poste']); ?></div></div>
            <div><div class="profil-label">Téléphone</div><div class="champ-bloc petit"><?php echo e($m['telephone']); ?></div></div>
        </div>
        <div class="profil-label" style="margin-top:18px;">Email</div>
        <div class="champ-bloc"><?php echo e($m['email']); ?></div>
        <div style="text-align:right;margin-top:24px;">
            <a class="bouton-principal btn-professionnel" style="display:inline-flex;width:auto;padding:12px 26px;" href="../traitements/deconnexion.php">Se déconnecter</a>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
