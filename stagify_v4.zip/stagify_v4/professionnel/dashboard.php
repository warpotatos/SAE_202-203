<?php
require_once "../includes/fonctions.php";
require_once "../config/connexion.php";
proteger("maitre_stage");

$racine = "../";
$versRacine = "../";
$actif = "dashboard.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Accueil professionnel</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<div class="contenu"><?php include "../includes/barre_recherche.php"; ?></div>
<div class="contenu">
    <a class="tuile large" href="stagiaires.php">Suivi stagiaires<span class="plus">+</span></a>
    <div class="grille-tuiles">
        <a class="tuile" href="candidatures.php">Demandes reçues<span class="plus">+</span></a>
        <a class="tuile" href="profil.php">Fiche contact<span class="plus">+</span></a>
        <a class="tuile" href="notes.php">Note &amp; Évaluation<span class="plus">+</span></a>
        <a class="tuile" href="creer_offre.php">Offre de Stage — Créer une offre<span class="plus">+</span></a>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
</body>
</html>
