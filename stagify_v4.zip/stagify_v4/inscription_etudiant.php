<?php
require_once "includes/fonctions.php";

$erreur = "";
if (isset($_GET['erreur'])) {
    $erreur = $_GET['erreur'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stagify — Inscription étudiant</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="page-centre">
        <div class="carte-auth large">
            <div class="entete-auth entete-etudiant">CRÉER UN COMPTE</div>
            <div class="corps-auth">

                <?php if ($erreur != "") { ?>
                    <div class="erreur"><?php echo e($erreur); ?></div>
                <?php } ?>

                <form action="traitements/inscription.php" method="post">
                    <input type="hidden" name="role" value="etudiant">

                    <div class="grille-2">
                        <div>
                            <label>NOM</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
                                <input type="text" name="nom" required>
                            </div>
                        </div>
                        <div>
                            <label>Prénom</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
                                <input type="text" name="prenom" required>
                            </div>
                        </div>
                        <div class="pleine">
                            <label>Email</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
                                <input type="email" name="email" required>
                            </div>
                        </div>
                        <div>
                            <label>Mot de passe</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>
                                <input type="password" name="motdepasse" pattern="(?=.*[A-Z])(?=.*\d).{8,}" required>
                            </div>
                        </div>
                        <div>
                            <label>Identifiant</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M13 10h4M13 14h4"/></svg>
                                <input type="text" name="login" required>
                            </div>
                        </div>
                    </div>
                    <p class="aide">Mot de passe : au moins 8 caractères, dont une majuscule et un chiffre.</p>

                    <div class="section-info">information étudiant</div>
                    <div class="grille-2">
                        <div>
                            <label>Téléphone</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4h4l2 5-3 2a11 11 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>
                                <input type="text" name="telephone">
                            </div>
                        </div>
                        <div>
                            <label>Groupe TD</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5M15 20c0-2 1-3.5 3.5-3.5"/></svg>
                                <input type="text" name="td" placeholder="TD1">
                            </div>
                        </div>
                        <div class="pleine">
                            <label>Groupe TP</label>
                            <div class="champ-icone">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5M15 20c0-2 1-3.5 3.5-3.5"/></svg>
                                <input type="text" name="tp" placeholder="TP2">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="bouton-principal btn-etudiant">Créer mon compte</button>
                </form>
                <a href="inscription.php" class="bouton-principal btn-etudiant" style="background:#9ec6f2;">← Retour</a>
            </div>
        </div>
    </div>
</body>
</html>
