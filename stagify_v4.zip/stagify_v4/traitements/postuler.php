<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("etudiant");

$idOffre   = (int) $_POST['offre'];
$motivation= $_POST['motivation'];
$duree     = $_POST['duree'];

$req = $pdo->prepare("SELECT id_etudiant FROM etudiant WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$etudiant = $req->fetch();
$idEtudiant = $etudiant['id_etudiant'];

$verif = $pdo->prepare("SELECT 1 FROM postulation WHERE id_etudiant = ? AND num_offre = ?");
$verif->execute([$idEtudiant, $idOffre]);

if (!$verif->fetch()) {
    $ajout = $pdo->prepare("INSERT INTO postulation (id_etudiant, num_offre, motivation, duree_souhaitee)
                            VALUES (?, ?, ?, ?)");
    $ajout->execute([$idEtudiant, $idOffre, $motivation, $duree]);
}

header("Location: ../etudiant/candidatures.php");
exit;
?>
