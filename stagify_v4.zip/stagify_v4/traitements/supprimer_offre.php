<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("admin");

$num = (int) $_GET['num'];
$req = $pdo->prepare("DELETE FROM offre_stage WHERE num_offre = ?");
$req->execute([$num]);

header("Location: ../admin/offres.php");
exit;
?>
