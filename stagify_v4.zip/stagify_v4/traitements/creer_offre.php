<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("maitre_stage");

$titre       = $_POST['titre'];
$description = $_POST['description'];
$competences = $_POST['competences'];
$remuneration= $_POST['remuneration'];
$duree       = $_POST['duree'];

$req = $pdo->prepare("SELECT id_maitre, id_entreprise FROM maitre_stage WHERE num_utilisateur = ?");
$req->execute([$_SESSION['user_id']]);
$maitre = $req->fetch();

$ajout = $pdo->prepare("INSERT INTO offre_stage
        (titre, description, duree, competences, remuneration, date_publication, statut, id_entreprise, id_maitre)
        VALUES (?, ?, ?, ?, ?, ?, 'ouverte', ?, ?)");
$ajout->execute([$titre, $description, $duree, $competences, $remuneration, date("Y-m-d"),
                 $maitre['id_entreprise'], $maitre['id_maitre']]);

header("Location: ../catalogue.php");
exit;
?>
