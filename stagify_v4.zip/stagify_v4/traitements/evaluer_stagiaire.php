<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("maitre_stage");

$numStage    = (int) $_POST['num_stage'];
$note        = $_POST['note'];
$appreciation= $_POST['appreciation'];

if ($note === "") {
    $note = null;
}

$verif = $pdo->prepare("SELECT 1
                        FROM stage s
                        JOIN maitre_stage m ON m.id_maitre = s.id_maitre
                        WHERE s.num_stage = ? AND m.num_utilisateur = ?");
$verif->execute([$numStage, $_SESSION['user_id']]);

if ($verif->fetch()) {
    $maj = $pdo->prepare("UPDATE stage SET appreciation = ?, note_maitre = ? WHERE num_stage = ?");
    $maj->execute([$appreciation, $note, $numStage]);
}

header("Location: ../professionnel/notes.php");
exit;
?>
