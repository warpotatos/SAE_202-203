<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";
proteger("admin");

$num = (int) $_GET['num'];

if ($num != $_SESSION['user_id']) {
    $req = $pdo->prepare("DELETE FROM utilisateur WHERE num_utilisateur = ?");
    $req->execute([$num]);
}

header("Location: ../admin/utilisateurs.php");
exit;
?>
