<?php
require_once "../includes/fonctions.php";

session_unset();
session_destroy();

header("Location: ../catalogue.php");
exit;
?>
