<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";

$login = $_POST['login'];
$motdepasse = $_POST['motdepasse'];

$espace = "etudiant";
if (isset($_POST['espace'])) {
    $espace = $_POST['espace'];
}

$requete = $pdo->prepare("SELECT * FROM utilisateur WHERE login = ?");
$requete->execute([$login]);
$utilisateur = $requete->fetch();

if ($utilisateur && password_verify($motdepasse, $utilisateur['mot_de_passe'])) {

    $_SESSION['user_id'] = $utilisateur['num_utilisateur'];
    $_SESSION['role'] = $utilisateur['role'];

    if ($utilisateur['role'] == "etudiant") {
        header("Location: ../etudiant/dashboard.php");
    } elseif ($utilisateur['role'] == "enseignant") {
        header("Location: ../enseignant/dashboard.php");
    } elseif ($utilisateur['role'] == "maitre_stage") {
        header("Location: ../professionnel/dashboard.php");
    } else {
        header("Location: ../admin/dashboard.php");
    }
    exit;

} else {
    header("Location: ../connexion_" . $espace . ".php?erreur=1");
    exit;
}
?>
