<?php
require_once "../config/connexion.php";
require_once "../includes/fonctions.php";

if (!estConnecte()) {
    header("Location: ../index.php");
    exit;
}

$destinataire = (int) $_POST['destinataire'];
$contenu = $_POST['contenu'];

if (trim($contenu) != "") {
    $req = $pdo->prepare("INSERT INTO message (expediteur, destinataire, contenu) VALUES (?, ?, ?)");
    $req->execute([$_SESSION['user_id'], $destinataire, $contenu]);
}

header("Location: ../messagerie.php?avec=" . $destinataire);
exit;
?>
